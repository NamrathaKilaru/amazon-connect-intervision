// Create service client module using ES6 syntax.
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";
// Set the AWS Region.
const REGION = "us-west-2"; //e.g. "us-east-1"
// Create an Amazon DynamoDB service client object.
const ddbClient = new DynamoDBClient({ region: REGION });

const marshallOptions = {
    // Whether to automatically convert empty strings, blobs, and sets to `null`.
    convertEmptyValues: false, // false, by default.
    // Whether to remove undefined values while marshalling.
    removeUndefinedValues: false, // false, by default.
    // Whether to convert typeof object to map attribute.
    convertClassInstanceToMap: false, // false, by default.
};

const unmarshallOptions = {
    // Whether to return numbers as a string instead of converting them to native JavaScript numbers.
    wrapNumbers: false, // false, by default.
};

const translateConfig = { marshallOptions, unmarshallOptions };

// Create the DynamoDB Document client.
const docClient = DynamoDBDocumentClient.from(ddbClient, translateConfig);

export const handler = async(event, context, callback) => {
    var phoneNumber = event.Details.ContactData.CustomerEndpoint.Address;
	var paramsQuery = {
				TableName: 'membershipTable',
  				KeyConditionExpression: "phoneNumber = :varNumber",

  				ExpressionAttributeValues: {
   					":varNumber": phoneNumber
  				}
 			};
  try {
    const data = await docClient.send(new QueryCommand(paramsQuery));
    console.log("Success. DynamoDB Query Results:" + JSON.stringify(data));
    // console.log("Success. Item details: ", data.Items);
   	if (data.Items.length === 1) {
	console.log(data.Items[0].membershipLevel);
	var membershipLevel = data.Items[0].membershipLevel;
	callback(null, buildResponse(true, membershipLevel));
   	} 
	else {
		console.log("PhoneNumber not found");
		callback(null, buildResponse(true, "none"));
   	}
  } catch (err) {
    console.log("Error", err);
    context.fail(buildResponse(false));
  }
};

function buildResponse(isSuccess, membershipLevel) {
 	if (isSuccess) {
  		return { 
			membershipLevel: membershipLevel,
			lambdaResult: "Success"
		};
 	} 
	else {
  		console.log("Lambda returned error to Connect");
  		return { lambdaResult: "Error" };
 	}
}